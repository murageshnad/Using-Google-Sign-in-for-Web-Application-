var express = require('express');
var app = express();

//Middle ware to fetch the contents

//adding middle ware custom

function welcomeNote(req, res, next){
    res.write('<h1 align="center">Dept of MCA</h1>');
    next();

}

app.use(welcomeNote);

//current date function- closure function
var currentDate = function (req, res, next){
    req.currentDate = new Date();
    next();

}

app.use(currentDate);

//middle ware to fetch the contents

app.get('/user', function(req, res){
    res.end('<h3 align="center"> Good Time To Begin -'+req.currentDate+'</h3>');

});

//middle ware to fetch the contents

app.get('/user', function(req, res){
    res.end('<h3 align="center"> Welcome To MEAN !!!</h3>');

});

//Start the server with some port
app.listen(3000);