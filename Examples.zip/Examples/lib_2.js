var message = '!!! ANGULRJS !!!';
exports.welcomeNote = function () {
    console.log(message);
};