var message = 'Welcome to Full Stack Development!';
exports.welcomeNote = function () {

    console.log(message);

};