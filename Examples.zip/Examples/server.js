var http = require('http');
var lib1 = require('./lib_1');
var lib2 = require('./lib_2');

var filecontent = require('fs');


http.createServer(function (req, res) {
    res.writeHead(200, {
        'Content-Type': 'utf8'
    });
    res.end('<h1 align="center">Hello World\n</h1>');
}).listen(3000, "127.0.0.1");
console.log('Server running at http://127.0.0.1:3000/');

console.log('Calling lib_1');
lib1.welcomeNote();

console.log('Calling lib_2');
lib2.welcomeNote();

console.log('Calling read operation');
filecontent.readFile('sample_login.html','utf8', function(err, data){
    if(err){
        console.log(err);
    }
    else{
        console.log(data);
    }
});