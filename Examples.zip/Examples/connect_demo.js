var connect = require("connect");
var app = connect();

function welcome(req, res, next){
    res.setHeader('Content-Type', 'text/plain');
    res.write('WELCOME TO Connect_demo DEVELOPMENT');
    next();
}

function check(req, res, next){
    
    res.end('checker 111');
}


app 
    .use('/welcome',welcome)
    .use('',check)
    .listen(3000);

console.log("Server is listening !!!");